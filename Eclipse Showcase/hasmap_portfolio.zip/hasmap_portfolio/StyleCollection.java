import java.util.HashMap;

class StyleCollection {
  private HashMap<String, Style> styles;
  
  public  StyleCollection() {
    styles = new HashMap<String, Style>();
  }

  public void addStyle(Style style) {
    styles.put(style.getName(),style);
  }

  public void setDefault(Style style) {
     styles.put("default",style);
  }
  
  public Style getStyle( String key) {
    return styles.get(key);
  }
  
  public Style getDefaultStyle() {
    return getStyle("default");
  }
}
