import java.util.ArrayList;
import java.util.Collections;

public class PhoneList {             // create the class

  private ArrayList<Phone> phones;       // make arraylist

  public PhoneList() {                               // create a new object for movies
    phones = new ArrayList<Phone>();
  }
  public void addPhone(Phone phone) {       // adding a movie
    phones.add(phone);
  }
  public int getNumberOfPhones() {
    return phones.size();    // adding the number of movies returned
  }
  public String toString() {
  String result = "";
  for (int index = 0; index < phones.size(); index++) {
            Phone phone = phones.get(index);
            result = result + phone.toString();
            result = result + "\n";
  }
  return result;
}
   public void sort() {
  Collections.sort(phones);
}
  
  
}
