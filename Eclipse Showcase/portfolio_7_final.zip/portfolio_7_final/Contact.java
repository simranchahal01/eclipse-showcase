class Contact {
  private String firstname;
  private String lastname;
  private String email;
  private int number;

  public Contact(String f, String l, String e, int n) {
    firstname = f;
    lastname = l;
    email = e;
    number = n;
  }
  
  public String toString() {
    return firstname + "\n" + lastname + "\n" + email + "\n" + number;
  }
}
  
  
  
